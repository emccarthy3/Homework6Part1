#CSC462
=======

Repository of starting code for all homework assignments for the fall 2016 semester at Elon. 

The code must be kept secured with no access allowed other than to your assigned team mate and the instructor, Dave Powell
